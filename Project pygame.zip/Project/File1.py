import os
import sys
import pygame
import csv
from math import fabs, copysign


pygame.init()
size = WIDTH, HEIGHT = 1000, 1000
display = pygame.display
screen = pygame.display.set_mode(size)
mus = pygame.mixer.music
mus.load('data/music.mp3')
mus.set_volume(0.15)
sound = pygame.mixer.Sound('data/sound.mp3')
sound.set_volume(0.7)
flPause = True
level_posx = 1
level_posy = 1


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    if colorkey is not None:
        image = image.convert()
        if colorkey == -1:
            colorkey = image.get_at((0, 0))
        image.set_colorkey(colorkey)
    else:
        image = image.convert_alpha()
    return image


FPS = 20
def terminate():
    pygame.quit()
    sys.exit()


def start_screen():
    intro_text = ["     W", "  A S D", "to move", "", "","SPACE", "to stop", "music"]
    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 80)
    text_coord = 200
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 50
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                mus.play(-1, 1.2)
                return  # начинаем игру
        pygame.display.flip()
        clock.tick(FPS)

def end_screen():
    intro_text = ["поздравляем"]
    fon = pygame.transform.scale(load_image('fon.jpg'), (WIDTH, HEIGHT))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 100)
    text_coord = 450
    for line in intro_text:
        string_rendered = font.render(line, 1, pygame.Color('black'))
        intro_rect = string_rendered.get_rect()
        text_coord += 10
        intro_rect.top = text_coord
        intro_rect.x = 400
        text_coord += intro_rect.height
        screen.blit(string_rendered, intro_rect)

    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                terminate()
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                terminate()
        pygame.display.flip()
        clock.tick(FPS)


tile_images = {
    'wall': load_image('box.png'),
    'grass1': load_image('grass1.png'),
    'grass2': load_image('grass2.png'),
    'grass3': load_image('grass3.png'),
    'ground1': load_image('ground1.png'),
    'tree1': load_image('tree1.png'),
    'enemy1': load_image('enemy1.png')
}

player_image = load_image('guy.png')
enemy_image = load_image('enemy1.png')
tile_width = tile_height = 100

player = None
# группы спрайтов
all_sprites = pygame.sprite.Group()
other_sprites = pygame.sprite.Group()
tiles_group = pygame.sprite.Group()
player_group = pygame.sprite.Group()
borders = []
enemies = []


class Tile(pygame.sprite.Sprite):
    def __init__(self, tile_type, pos_x, pos_y):
        super().__init__(tiles_group, all_sprites)
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.image = tile_images[tile_type]
        self.rect = self.image.get_rect().move(
            tile_width * self.pos_x, tile_height * self.pos_y)


class Player(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = player_image
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.rect = self.image.get_rect().move(
            tile_width * self.pos_x + (tile_width // 2 - self.image.get_rect().w // 2),
            tile_height * self.pos_y + (tile_width // 2 - self.image.get_rect().h // 2))

    def change_im(self, image):
        self.image = image

    def update(self, args):
        move_x = 0
        move_y = 0
        if args[pygame.K_LEFT]:
            move_x += -8
        if args[pygame.K_RIGHT]:
            move_x += 8
        if args[pygame.K_UP]:
            move_y += -8
        if args[pygame.K_DOWN]:
            move_y += 8
        if ([(self.rect.x + move_x) // tile_width, (self.rect.y + move_y) // tile_width] in borders or
                [(self.rect.x + move_x) // tile_width, (self.rect.y + self.rect.h + move_y) // tile_width] in borders) \
            or ([(self.rect.x + self.rect.w + move_x) // tile_width, (self.rect.y + move_y) // tile_width] in borders or
                [(self.rect.x + self.rect.w + move_x) // tile_width, (self.rect.y + self.rect.h + move_y) // tile_width] in borders):
            move_x = 0
            move_y = 0
        if fabs(move_x) == fabs(move_y):
            move_x = copysign(fabs(move_x) / 1.5, move_x)
            move_y = copysign(fabs(move_y) / 1.5, move_y)
        if move_x != 0 or move_y != 0:
            if move_x != 0:
                if move_x > 0:
                    walk_right.update()
                else:
                    walk_left.update()
            if move_y != 0:
                if move_y > 0:
                    walk_down.update()
                else:
                    walk_up.update()
        else:
            self.change_im(load_image("guy.png"))
        if self.rect.x + self.rect.w + move_x > WIDTH or self.rect.x + move_x < 0 or \
                self.rect.y + move_y < 0 or self.rect.y + self.rect.h + move_y > HEIGHT:
            self.next_level(move_x, move_y)
            move_x,  move_y = 0, 0
        self.rect.x += move_x
        self.rect.y += move_y

    def next_level(self, move_x, move_y):
        global player, level_posx, level_posy, level_x, level_y, enemy
        x, y = None, None
        if self.rect.x + self.rect.w + move_x > WIDTH:
            level_posx += 1
            x = 0
            y = self.rect.y // tile_width
        elif self.rect.x + move_x < 0:
            level_posx -= 1
            x = level_x
            y = self.rect.y // tile_width
        elif self.rect.y + move_y < 0:
            level_posy -= level_y
            x = self.rect.x // tile_width
            y = level_y
        elif self.rect.y + self.rect.h + move_y > HEIGHT:
            level_posy += 1
            x = self.rect.x // tile_width
            y = 0
        borders.clear()
        sound.play()
        player, enemy, level_x, level_y = generate_level(load_level(f'level{level_posx}{level_posy}.csv'), x, y, 1, 1)


class AnimatedSprite(pygame.sprite.Sprite):
    def __init__(self, sheet, columns, rows, x, y):
        super().__init__(other_sprites, all_sprites)
        self.frames = []
        self.cut_sheet(sheet, columns, rows)
        self.cur_frame = 0
        self.image = self.frames[self.cur_frame]
        self.rect = self.rect.move(x, y)

    def cut_sheet(self, sheet, columns, rows):
        self.rect = pygame.Rect(0, 0, sheet.get_width() // columns, sheet.get_height() // rows)
        for j in range(rows):
            for i in range(columns):
                frame_location = (self.rect.w * i, self.rect.h * j)
                self.frames.append(sheet.subsurface(pygame.Rect(frame_location, self.rect.size)))

    def update(self):
        self.cur_frame = (self.cur_frame + 1) % len(self.frames)
        self.image = self.frames[self.cur_frame]
        player.change_im(self.image)


walk_up = AnimatedSprite(load_image("character_move_up.png"), 8, 2, 64, 64)
walk_down = AnimatedSprite(load_image("character_move_down.png"), 8, 2, 64, 64)
walk_left = AnimatedSprite(load_image("character_move_left.png"), 8, 2, 64, 64)
walk_right = AnimatedSprite(load_image("character_move_right.png"), 8, 2, 64, 64)


def load_level(filename):
    filename = "data/" + filename
    with open(filename, encoding="utf8") as csvfile:
        reader = csv.reader(csvfile, delimiter=';', quotechar='"')
        return list(reader)


def generate_level(level, st_x, st_y, en_x, en_y):
    new_player, x, y = None, None, None
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '#':
                Tile('wall', x, y)
                borders.append([x, y])

            elif level[y][x] == "grass1":
                Tile("grass1", x, y)

            elif level[y][x] == "grass2":
                Tile("grass2", x, y)

            elif level[y][x] == "grass3":
                Tile("grass3", x, y)

            elif level[y][x] == "ground1":
                Tile("ground1", x, y)

            elif level[y][x] == "tree1":
                Tile("tree1", x, y)
                borders.append([x, y])

    if len(player_group):
        player.kill()
    new_player = Player(st_x, st_y)
    enemy = Enemy(en_x, en_y)
    return new_player, enemy, x, y

class Enemy(pygame.sprite.Sprite):
    def __init__(self, pos_x, pos_y):
        super().__init__(player_group, all_sprites)
        self.image = enemy_image
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.rect = self.image.get_rect().move(
            tile_width * self.pos_x + (tile_width // 2 - self.image.get_rect().w // 2),
            tile_height * self.pos_y + (tile_width // 2 - self.image.get_rect().h // 2))
        self.rl = 1
        self.mask = pygame.mask.from_surface(self.image)

    def enemy_go(self):
        move_x = 0
        if self.rl == 1:
            move_x += 20
            if ([(self.rect.x + move_x) // tile_width, self.rect.y // tile_width] in borders or
                [(self.rect.x + move_x) // tile_width,
                 (self.rect.y + self.rect.h) // tile_width] in borders) \
                    or ([(self.rect.x + self.rect.w + move_x) // tile_width,
                         self.rect.y // tile_width] in borders or
                        [(self.rect.x + self.rect.w + move_x) // tile_width,
                         (self.rect.y + self.rect.h) // tile_width] in borders):
                self.rl = -1
        else:
            move_x -= 20
            if ([(self.rect.x + move_x) // tile_width, self.rect.y // tile_width] in borders or
                [(self.rect.x + move_x) // tile_width,
                 (self.rect.y + self.rect.h) // tile_width] in borders) \
                    or ([(self.rect.x + self.rect.w + move_x) // tile_width,
                         self.rect.y // tile_width] in borders or
                        [(self.rect.x + self.rect.w + move_x) // tile_width,
                         (self.rect.y + self.rect.h) // tile_width] in borders):
                self.rl = 1
        self.rect.x += move_x
        if pygame.sprite.collide_mask(self, player):
            player.kill()


clock = pygame.time.Clock()
start_screen()
player, enemy, level_x, level_y = generate_level(load_level(f'level{level_posx}{level_posy}.csv'), 5, 5, 1, 1)
font = pygame.font.Font(None, 30)
text_coord = 50
while True:
    screen.fill(pygame.Color('black'))
    clock.tick(FPS)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                flPause = not flPause
                if flPause:
                    pygame.mixer.music.pause()
                else:
                    pygame.mixer.music.unpause()
    enemy.enemy_go()
    player_group.update(pygame.key.get_pressed())
    all_sprites.draw(screen)
    display.flip()
